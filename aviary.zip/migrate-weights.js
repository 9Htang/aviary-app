// 迁移：添加体重记录表
const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'aviary.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS weight_records (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    bird_id     INTEGER NOT NULL REFERENCES birds(id) ON DELETE CASCADE,
    weight      REAL NOT NULL,
    recorded_at TEXT NOT NULL,
    notes       TEXT,
    created_at  TEXT DEFAULT (datetime('now', 'localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_weight_bird ON weight_records(bird_id);
`);

console.log('✅ weight_records 表已创建');
db.close();
