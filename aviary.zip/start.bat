@echo off
chcp 65001 >nul
echo 🦜 鸟舍管理系统 — 初始化
echo ==========================
echo.

REM 检查 Node.js
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo ❌ 未检测到 Node.js！
  echo 请先安装 Node.js: https://nodejs.org/
  echo 安装后重新运行本脚本
  pause
  exit /b 1
)

echo ✅ Node.js 已安装
echo.

REM 检查依赖
if not exist "node_modules" (
  echo 📦 正在安装依赖...
  npm install express better-sqlite3 ejs multer sharp
  echo ✅ 依赖安装完成
)

REM 初始化数据库（如果没有的话）
if not exist "aviary.db" (
  echo 🗄️ 正在创建数据库...
  node init-db.js
  echo ✅ 数据库已创建
)

echo 🚀 启动服务...
echo.
echo 📎 访问地址: http://127.0.0.1:3456
echo 📎 局域网手机: http://你的IP:3456
echo.
echo 按 Ctrl+C 停止服务
echo.

node server.js
pause
