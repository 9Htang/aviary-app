const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'aviary.db');
// 删除旧的（仅首次建表用）
if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ====== 建表 ======

db.exec(`
  -- 品种
  CREATE TABLE species (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name_cn       TEXT    NOT NULL UNIQUE,  -- 中文名：牡丹鹦鹉
    name_en       TEXT,                      -- English name
    scientific    TEXT,                      -- 学名
    notes         TEXT
  );

  -- 个体鸟
  CREATE TABLE birds (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT    NOT NULL,         -- 名字/昵称
    species_id      INTEGER NOT NULL REFERENCES species(id),
    gender          TEXT    CHECK(gender IN ('公','母','未知')),
    hatch_date      TEXT,                    -- YYYY-MM-DD
    color_desc      TEXT,                    -- 羽色描述，如"原始灰"
    father_id       INTEGER REFERENCES birds(id),
    mother_id       INTEGER REFERENCES birds(id),
    ring_number     TEXT    UNIQUE,               -- 脚环号（唯一，查询主键）
    status          TEXT    DEFAULT '存活' CHECK(status IN ('存活','死亡','转让')),
    breeding_status TEXT    DEFAULT '可配对' CHECK(breeding_status IN ('可配对','已配对','休养','退役')),
    source          TEXT,                    -- 来源：自家繁殖/购入
    image_path      TEXT,                    -- 缩略图文件名
    notes           TEXT,
    created_at      TEXT    DEFAULT (datetime('now','localtime'))
  );

  -- 脚环号索引（加速查询）
  CREATE INDEX idx_birds_ring ON birds(ring_number);

  -- 谱系索引（加速查父母/子女）
  CREATE INDEX idx_birds_father ON birds(father_id);
  CREATE INDEX idx_birds_mother ON birds(mother_id);

  -- 基因/变异/品系（各品种特有的遗传特征）
  CREATE TABLE mutations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    species_id      INTEGER NOT NULL REFERENCES species(id),
    name            TEXT    NOT NULL,         -- 派特、黄化、珍珠...
    inheritance     TEXT    CHECK(inheritance IN ('显性遗传','隐性遗传','性联遗传','不完全显性','多基因遗传','未知')),
    description     TEXT,
    UNIQUE(species_id, name)
  );

  -- 个体基因型（一只鸟可以有多个基因）
  CREATE TABLE bird_mutations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    bird_id         INTEGER NOT NULL REFERENCES birds(id) ON DELETE CASCADE,
    mutation_id     INTEGER NOT NULL REFERENCES mutations(id),
    genotype        TEXT    CHECK(genotype IN ('纯合','杂合','单因子','双因子','携带','未知')),
    notes           TEXT,
    UNIQUE(bird_id, mutation_id)
  );

  -- 配对记录
  CREATE TABLE pairings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    male_id         INTEGER NOT NULL REFERENCES birds(id),
    female_id       INTEGER NOT NULL REFERENCES birds(id),
    start_date      TEXT    NOT NULL,          -- YYYY-MM-DD
    end_date        TEXT,                      -- 拆对日期
    status          TEXT    DEFAULT '已配对' CHECK(status IN ('已配对','已拆对','永久配对')),
    pair_name       TEXT,                      -- 配对代称，如"皮皮×豆豆"
    notes           TEXT,
    created_at      TEXT    DEFAULT (datetime('now','localtime'))
  );

  -- 繁殖事件（每窝）
  CREATE TABLE breeding_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pair_id         INTEGER NOT NULL REFERENCES pairings(id),
    event_date      TEXT    NOT NULL,          -- 下蛋/出雏日期
    clutch_number   INTEGER,                   -- 第几窝
    egg_count       INTEGER DEFAULT 0,
    hatch_count     INTEGER DEFAULT 0,
    weaned_count    INTEGER DEFAULT 0,
    notes           TEXT,
    created_at      TEXT    DEFAULT (datetime('now','localtime'))
  );

  -- 繁殖后代（连接到个体表）
  CREATE TABLE offspring (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    breeding_event_id   INTEGER NOT NULL REFERENCES breeding_events(id),
    bird_id             INTEGER NOT NULL REFERENCES birds(id) ON DELETE CASCADE,
    hatch_order         INTEGER,               -- 排行第几
    notes               TEXT
  );

  -- 近亲关系记录（缓存计算结果）
  CREATE TABLE relationship_cache (
    bird_a_id       INTEGER NOT NULL REFERENCES birds(id),
    bird_b_id       INTEGER NOT NULL REFERENCES birds(id),
    relationship    TEXT    NOT NULL,          -- 例如：兄妹、父女、堂兄妹
    coef_inbreeding REAL,                      -- 近亲系数 (0~1)
    checked_at      TEXT    DEFAULT (datetime('now','localtime')),
    PRIMARY KEY (bird_a_id, bird_b_id)
  );

  -- 体重记录
  CREATE TABLE weight_records (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    bird_id     INTEGER NOT NULL REFERENCES birds(id) ON DELETE CASCADE,
    weight      REAL NOT NULL,
    recorded_at TEXT NOT NULL,
    notes       TEXT,
    created_at  TEXT DEFAULT (datetime('now', 'localtime'))
  );
  CREATE INDEX idx_weight_bird ON weight_records(bird_id);
`);

console.log('✅ aviary.db 已创建');
db.close();
