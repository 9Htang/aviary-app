# 🦜 鸟舍管理系统

本地鹦鹉鸟舍管理工具，SQLite + Express.js + EJS。

## 快速开始

### 1. 安装 Node.js

去 https://nodejs.org/ 下载 LTS 版本，安装。

### 2. 启动

**Windows**: 双击 `start.bat`
**手动**:
```
cd 解压目录
npm install express better-sqlite3 ejs multer sharp
node server.js
```

### 3. 打开

浏览器访问 http://127.0.0.1:3456

手机在同一局域网可访问 http://你电脑的IP:3456

### 4. 首次使用

启动后自动创建空数据库，有初始品种（牡丹鹦鹉）和基因库。直接点「新增鸟只」开始录入。

## 常见问题

**端口被占用？**
修改 server.js 里的 `PORT = 3456` 换个端口。

**怎么加其他品种？**
新增鸟只时下拉选「新增品种」即可。
