const express = require('express');
const Database = require('better-sqlite3');
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3456;

const db = new Database(path.join(__dirname, 'aviary.db'));
db.pragma('foreign_keys = ON');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/static', express.static(path.join(__dirname, 'public')));

const uploadDir = path.join(__dirname, 'public', 'uploads');
const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

function findBirdByRef(ref) {
  if (!ref || !ref.trim()) return null;
  ref = ref.trim();
  let bird;
  if (/^\d+$/.test(ref)) bird = db.prepare('SELECT id, name, ring_number FROM birds WHERE id=?').get(parseInt(ref));
  if (!bird) bird = db.prepare('SELECT id, name, ring_number FROM birds WHERE ring_number=?').get(ref);
  if (!bird) bird = db.prepare('SELECT id, name, ring_number FROM birds WHERE name=?').get(ref);
  return bird;
}

// ====== 路由 ======

app.get('/', (req, res) => {
  autoUpdateBreedingStatus();
  res.set('Cache-Control', 'no-store');
  const q = (req.query.q || '').trim();
  const g = req.query.gender || '';
  const sp = req.query.species || '';
  const st = req.query.status || '';
  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();

  // 构建筛选条件
  let where = [];
  let params = [];

  if (q) {
    if (/^\d+$/.test(q)) {
      birds = db.prepare(`
        SELECT b.id, b.name, b.ring_number, b.gender, b.color_desc, b.species_id,
          b.image_path, b.status, b.breeding_status, b.hatch_date, s.name_cn AS species
        FROM birds b JOIN species s ON s.id = b.species_id WHERE b.id = ?
        ORDER BY b.id
      `).all(parseInt(q));
      // 直接渲染
      const cacheBust = Date.now();
      return res.render('index', { species, birds, cacheBust, searchQuery: q, filterGender: g, filterSpecies: sp, filterStatus: st });
    } else {
      where.push('(b.ring_number LIKE ? OR b.name LIKE ? OR s.name_cn LIKE ?)');
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
  }

  if (g) { where.push('b.gender=?'); params.push(g); }
  if (sp) { where.push('b.species_id=?'); params.push(parseInt(sp)); }
  if (st) { where.push('b.breeding_status=?'); params.push(st); }

  let sql = `
    SELECT b.id, b.name, b.ring_number, b.gender, b.color_desc, b.species_id,
      b.image_path, b.status, b.breeding_status, b.hatch_date, s.name_cn AS species
    FROM birds b JOIN species s ON s.id = b.species_id`;
  if (where.length > 0) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY b.id';

  birds = db.prepare(sql).all(...params);

  const cacheBust = Date.now();
  res.render('index', { species, birds, cacheBust, searchQuery: q, filterGender: g, filterSpecies: sp, filterStatus: st });
});

app.get('/search', (req, res) => {
  res.set('Cache-Control', 'no-store');
  const q = (req.query.q || '').trim();
  const g = req.query.gender || '';
  if (!q) return res.redirect('/');

  let birds;
  if (/^\d+$/.test(q)) {
    birds = db.prepare(`
      SELECT b.*, s.name_cn AS species
      FROM birds b JOIN species s ON s.id = b.species_id WHERE b.id = ?
    `).all(parseInt(q));
  } else {
    let sql = `
      SELECT b.*, s.name_cn AS species
      FROM birds b JOIN species s ON s.id = b.species_id
      WHERE (b.ring_number LIKE ? OR b.name LIKE ? OR s.name_cn LIKE ?)`;
    const params = [`%${q}%`, `%${q}%`, `%${q}%`];
    if (g) {
      sql += ` AND b.gender=?`;
      params.push(g);
    }
    sql += ` ORDER BY b.name`;
    birds = db.prepare(sql).all(...params);
  }
  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();
  res.render('search', { query: q, birds, species, filterGender: g });
});

app.get('/bird/:id', (req, res) => {
  res.set('Cache-Control', 'no-store');
  const id = parseInt(req.params.id);
  const bird = db.prepare(`
    SELECT b.*, s.name_cn AS species
    FROM birds b JOIN species s ON s.id = b.species_id WHERE b.id = ?
  `).get(id);
  if (!bird) return res.redirect('/?notfound=1');

  const genes = db.prepare(`
    SELECT m.name, bm.genotype, m.inheritance
    FROM bird_mutations bm JOIN mutations m ON m.id = bm.mutation_id WHERE bm.bird_id = ?
  `).all(id);

  const father = bird.father_id ? db.prepare('SELECT id, name, ring_number FROM birds WHERE id=?').get(bird.father_id) : null;
  const mother = bird.mother_id ? db.prepare('SELECT id, name, ring_number FROM birds WHERE id=?').get(bird.mother_id) : null;

  const children = db.prepare(`
    SELECT id, name, ring_number, gender, color_desc, hatch_date, father_id, mother_id
    FROM birds WHERE father_id=? OR mother_id=? ORDER BY hatch_date
  `).all(id, id);

  const pairings = db.prepare(`
    SELECT p.id, p.start_date, p.end_date, p.status, p.pair_name,
      CASE WHEN p.male_id=? THEN '♂' ELSE '♀' END AS role,
      b2.id AS mate_id, b2.name AS mate_name, b2.ring_number AS mate_ring
    FROM pairings p JOIN birds b2 ON b2.id = CASE WHEN p.male_id=? THEN p.female_id ELSE p.male_id END
    WHERE p.male_id=? OR p.female_id=? ORDER BY p.start_date DESC
  `).all(id, id, id, id);

  const currentMate = db.prepare(`
    SELECT p.id, p.start_date, p.pair_name,
      CASE WHEN p.male_id=? THEN '♂' ELSE '♀' END AS role,
      b2.id AS mate_id, b2.name AS mate_name, b2.ring_number AS mate_ring
    FROM pairings p JOIN birds b2 ON b2.id = CASE WHEN p.male_id=? THEN p.female_id ELSE p.male_id END
    WHERE (p.male_id=? OR p.female_id=?) AND p.status='已配对' ORDER BY p.start_date DESC LIMIT 1
  `).get(id, id, id, id);

  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();

  // 可选配偶（同品种、异性、未配对）
  const oppositeGender = bird.gender === '公' ? '母' : '公';
  const availableMates = db.prepare(`
    SELECT id, name, ring_number, gender, color_desc, image_path
    FROM birds
    WHERE species_id=? AND gender=? AND breeding_status='未配对' AND id!=?
    ORDER BY name
  `).all(bird.species_id, oppositeGender, id);

  // 繁殖记录（当前活跃配对的每窝）
  const breedingEvents = [];
  if (currentMate) {
    const events = db.prepare(`
      SELECT be.*, p.male_id, p.female_id, p.pair_name
      FROM breeding_events be
      JOIN pairings p ON p.id = be.pair_id
      WHERE (p.male_id=? OR p.female_id=?) AND p.status='已配对'
      ORDER BY be.event_date DESC
    `).all(id, id);
    breedingEvents.push(...events);
  }

  // 子女另一方亲鸟信息
  const childrenWithParent = children.map(c => {
    const other = db.prepare(`
      SELECT id, name, ring_number FROM birds WHERE id = CASE WHEN ? IS NOT NULL AND ? != father_id THEN father_id ELSE mother_id END
    `).get(id, id);
    const otherParent = db.prepare(`
      SELECT id, name, ring_number FROM birds WHERE id = CASE WHEN father_id=? THEN mother_id ELSE father_id END AND (father_id=? OR mother_id=?)
    `).get(id, c.id, c.id);
    // simpler: just find which parent is not this bird
    const otherP = c.father_id === bird.id
      ? (c.mother_id ? db.prepare('SELECT id,name,ring_number FROM birds WHERE id=?').get(c.mother_id) : null)
      : (c.father_id ? db.prepare('SELECT id,name,ring_number FROM birds WHERE id=?').get(c.father_id) : null);
    return { ...c, otherParent: otherP };
  });

  const weightRecords = db.prepare('SELECT id, weight, recorded_at, notes FROM weight_records WHERE bird_id=? ORDER BY recorded_at ASC').all(id);

  const pageError = req.query.err || null;
  res.render('bird', { bird, genes, father, mother, children: childrenWithParent, pairings, currentMate, species, availableMates, breedingEvents, weightRecords, pageError });
});

// ---- 基因计算器 ----
app.get('/genetics', (req, res) => {
  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();
  const birds = db.prepare('SELECT id, name, ring_number, gender, species_id FROM birds ORDER BY name').all();
  res.render('genetics', { birds, species });
});

// ---- 基因计算器 API ----
app.get('/api/bird/:id/genes', (req, res) => {
  const id = parseInt(req.params.id);
  const genes = db.prepare('SELECT mutation_id, genotype FROM bird_mutations WHERE bird_id=?').all(id);
  res.json(genes);
});

app.get('/api/mutations', (req, res) => {
  const mutations = db.prepare('SELECT id, name, inheritance FROM mutations ORDER BY species_id, name').all();
  res.json(mutations);
});

// ---- 新增鸟 API - 父母候选名单 ----
app.get('/api/birds/parent-candidates', (req, res) => {
  const birds = db.prepare(`
    SELECT b.id, b.name, b.ring_number, b.gender, b.species_id, b.color_desc,
      b.breeding_status, b.source, b.image_path, b.status,
      s.name_cn AS species_name
    FROM birds b JOIN species s ON s.id = b.species_id
    ORDER BY b.id
  `).all();
  res.json(birds);
});

// ---- 体重 API ----
app.get('/api/bird/:id/weights', (req, res) => {
  const id = parseInt(req.params.id);
  const records = db.prepare('SELECT id, weight, recorded_at, notes FROM weight_records WHERE bird_id=? ORDER BY recorded_at ASC').all(id);
  res.json(records);
});

app.post('/api/bird/:id/weight', (req, res) => {
  const id = parseInt(req.params.id);
  const { weight, recorded_at, notes } = req.body;
  if (!weight || isNaN(weight)) return res.status(400).json({ error: '体重无效' });
  const at = recorded_at || new Date().toISOString().slice(0, 16).replace('T', ' ');
  // 检查同一小时内是否已有记录
  const hourKey = at.slice(0, 13); // 'YYYY-MM-DD HH'
  const existing = db.prepare("SELECT id, weight FROM weight_records WHERE bird_id=? AND substr(recorded_at,1,13)=?").get(id, hourKey);
  if (existing) {
    return res.status(409).json({ error: '该小时内已有体重记录', existing: existing });
  }
  db.prepare('INSERT INTO weight_records (bird_id, weight, recorded_at, notes) VALUES (?,?,?,?)').run(id, parseFloat(weight), at, notes || null);
  res.json({ ok: true });
});

app.put('/api/bird/:id/weight/:wid', (req, res) => {
  const wid = parseInt(req.params.wid);
  const { weight, recorded_at, notes } = req.body;
  if (!weight || isNaN(weight)) return res.status(400).json({ error: '体重无效' });
  const at = recorded_at || new Date().toISOString().slice(0, 16).replace('T', ' ');
  // 检查同一小时内是否已有其他记录（排除自己）
  const hourKey = at.slice(0, 13);
  const existing = db.prepare("SELECT id, weight FROM weight_records WHERE bird_id=? AND substr(recorded_at,1,13)=? AND id!=?").get(parseInt(req.params.id), hourKey, wid);
  if (existing) {
    return res.status(409).json({ error: '该小时内已有体重记录', existing: existing });
  }
  db.prepare('UPDATE weight_records SET weight=?, recorded_at=?, notes=? WHERE id=?').run(parseFloat(weight), at, notes || null, wid);
  res.json({ ok: true });
});

app.delete('/api/bird/:id/weight/:wid', (req, res) => {
  db.prepare('DELETE FROM weight_records WHERE id=?').run(parseInt(req.params.wid));
  res.json({ ok: true });
});

// ---- 新增鸟 ----
app.get('/add', (req, res) => {
  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();
  const mutations = db.prepare(`
    SELECT m.id, m.name, m.inheritance, m.species_id, s.name_cn AS species_name
    FROM mutations m JOIN species s ON s.id = m.species_id ORDER BY s.name_cn, m.name
  `).all();
  // 按品种分组
  const mutBySpecies = {};
  for (const m of mutations) {
    if (!mutBySpecies[m.species_id]) mutBySpecies[m.species_id] = [];
    mutBySpecies[m.species_id].push(m);
  }
  res.render('add', { species, mutBySpecies, form: {}, err: null });
});

app.post('/add', upload.any(), async (req, res) => {
  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();
  const mutations = db.prepare(`
    SELECT m.id, m.name, m.inheritance, m.species_id, s.name_cn AS species_name
    FROM mutations m JOIN species s ON s.id = m.species_id ORDER BY s.name_cn, m.name
  `).all();
  const mutBySpecies = {};
  for (const m of mutations) {
    if (!mutBySpecies[m.species_id]) mutBySpecies[m.species_id] = [];
    mutBySpecies[m.species_id].push(m);
  }

  const { name, species_id, gender, color_desc, hatch_year, hatch_month, hatch_day, ring_number,
    father_ref, mother_ref, source, status, breeding_status, notes, new_species, mate_id } = req.body;

  // 组合日期
  let hatchDate = null;
  if (hatch_year && hatch_month && hatch_day) {
    hatchDate = hatch_year + '-' + String(hatch_month).padStart(2,'0') + '-' + String(hatch_day).padStart(2,'0');
  }

  if (!name || !name.trim()) {
    return res.render('add', { species, mutBySpecies, form: req.body, err: '名字不能为空' });
  }

  // 新增已配对必须有配偶
  if (breeding_status === '已配对' && !mate_id) {
    return res.render('add', { species, mutBySpecies, form: req.body, err: '已配对必须选择配偶' });
  }

  let spId = parseInt(species_id);
  // 如果选了"新增品种"
  if (species_id === 'new' && new_species && new_species.trim()) {
    const exist = db.prepare('SELECT id FROM species WHERE name_cn=?').get(new_species.trim());
    if (exist) { spId = exist.id; }
    else {
      const r = db.prepare('INSERT INTO species (name_cn) VALUES (?)').run(new_species.trim());
      spId = r.lastInsertRowid;
    }
  }

  const fatherBird = findBirdByRef(father_ref);
  const motherBird = findBirdByRef(mother_ref);

  // 确定脚环号
  let ringVal = (ring_number || '').trim();
  if (!ringVal) ringVal = null;

  try {
    const info = db.prepare(`
      INSERT INTO birds (name, species_id, gender, color_desc, hatch_date, ring_number,
        father_id, mother_id, source, status, breeding_status, notes)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(name.trim(), spId, gender || '未知', color_desc || null, hatchDate, ringVal,
      fatherBird ? fatherBird.id : null, motherBird ? motherBird.id : null,
      source || '未知', status || '存活', breeding_status || '未配对', notes || null);

    const newId = info.lastInsertRowid;

    // 自动生成无脚环鸟的标识
    if (!ringVal) {
      db.prepare('UPDATE birds SET ring_number=? WHERE id=?').run('NULL' + newId, newId);
    }

    // 处理基因（从 checkbox 表单获取）
    const checkedMuts = req.body.mutations || {};
    const genotypes = req.body.genotypes || {};
    for (const mutId of Object.keys(checkedMuts)) {
      const mid = parseInt(mutId);
      if (!mid) continue;
      let gt = genotypes[mutId] || '携带'; // 无基因型下拉的（多基因）默认携带
      db.prepare('INSERT OR IGNORE INTO bird_mutations (bird_id, mutation_id, genotype) VALUES (?,?,?)').run(newId, mid, gt);
    }

    // 处理图片（支持 multer 文件和 base64 两种方式）
    let imgBuf = null;
    if (req.files && req.files.length > 0) {
      imgBuf = req.files[0].buffer;
    }
    if (!imgBuf && req.body.photo_data && req.body.photo_data.startsWith('data:')) {
      const b64 = req.body.photo_data.replace(/^data:image\/\w+;base64,/, '');
      imgBuf = Buffer.from(b64, 'base64');
    }

    if (imgBuf) {
      try {
        const thumbName = `bird_${newId}_${Date.now()}.jpg`;
        const thumbPath = path.join(uploadDir, thumbName);
        await sharp(imgBuf).resize({ height: 400, withoutEnlargement: true }).jpeg({ quality: 60 }).toFile(thumbPath);
        db.prepare('UPDATE birds SET image_path=? WHERE id=?').run(thumbName, newId);
      } catch (e) { console.error('图片处理失败:', e); }
    }

    // 如果新增的是已配对，创建配对记录
    if (breeding_status === '已配对' && mate_id) {
      const mid = parseInt(mate_id);
      const bird = { id: newId, gender: gender || '未知' };
      const mate = db.prepare('SELECT id, gender FROM birds WHERE id=?').get(mid);
      if (mate) {
        const maleId = bird.gender === '公' ? bird.id : mate.id;
        const femaleId = bird.gender === '母' ? bird.id : mate.id;

        // 解除 mate 原有的活跃配对
        const toEnd = db.prepare("SELECT id FROM pairings WHERE (male_id=? OR female_id=?) AND status='已配对'").all(mid, mid);
        for (const p of toEnd) {
          db.prepare("UPDATE pairings SET status='已拆对', end_date=date('now') WHERE id=?").run(p.id);
          const pp = db.prepare('SELECT male_id, female_id FROM pairings WHERE id=?').get(p.id);
          if (pp) {
            const other = pp.male_id === mid ? pp.female_id : pp.male_id;
            db.prepare("UPDATE birds SET breeding_status='未配对' WHERE id=? AND breeding_status='已配对'").run(other);
          }
        }

        db.prepare('INSERT INTO pairings (male_id, female_id, start_date, status) VALUES (?,?,date(\'now\'),\'已配对\')').run(maleId, femaleId);
        db.prepare("UPDATE birds SET breeding_status='已配对' WHERE id=?").run(mid);
      }
    }

    res.redirect(`/bird/${newId}`);
  } catch (e) {
    console.error('录入失败:', e);
    res.render('add', { species, mutBySpecies, form: req.body, err: '录入失败: ' + e.message });
  }
});

// 上传图片
app.post('/bird/:id/photo', upload.any(), async (req, res) => {
  const id = parseInt(req.params.id);

  let imageBuffer = null;
  // multer 文件
  if (req.files && req.files.length > 0) {
    imageBuffer = req.files[0].buffer;
  }
  // base64
  if (!imageBuffer && req.body.photo_data && req.body.photo_data.startsWith('data:')) {
    const b64 = req.body.photo_data.replace(/^data:image\/\w+;base64,/, '');
    imageBuffer = Buffer.from(b64, 'base64');
    console.log('✅ 收到 base64 图片, 长度:', b64.length);
  }

  if (!imageBuffer) return res.redirect(`/bird/${id}?err=nophoto`);

  try {
    const thumbName = `bird_${id}_${Date.now()}.jpg`;
    const thumbPath = path.join(uploadDir, thumbName);
    await sharp(imageBuffer).resize({ height: 400, withoutEnlargement: true }).jpeg({ quality: 60 }).toFile(thumbPath);
    const old = db.prepare('SELECT image_path FROM birds WHERE id=?').get(id);
    if (old && old.image_path) {
      const oldPath = path.join(uploadDir, path.basename(old.image_path));
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }
    db.prepare('UPDATE birds SET image_path=? WHERE id=?').run(thumbName, id);
    res.redirect(`/bird/${id}`);
  } catch (e) {
    console.error('图片处理失败:', e);
    res.redirect(`/bird/${id}?err=photo_fail`);
  }
});

// 编辑鸟
app.post('/bird/:id/edit', (req, res) => {
  const id = parseInt(req.params.id);
  const { name, gender, color_desc, hatch_date, ring_number, father_id, mother_id, status, breeding_status, source, notes, mate_id } = req.body;

  // 已配对必须有配偶
  if (breeding_status === '已配对' && !mate_id) {
    return res.redirect('/bird/' + id + '?err=nomate');
  }

  db.prepare(`
    UPDATE birds SET name=?, gender=?, color_desc=?, hatch_date=?, ring_number=?,
      father_id=?, mother_id=?, status=?, breeding_status=?, source=?, notes=?
    WHERE id=?
  `).run(name, gender, color_desc, hatch_date || null, ring_number || null,
    father_id || null, mother_id || null, status, breeding_status, source || null, notes || null, id);

  // 如果改为非配对（未配对/不可配对），解除已有的活跃配对
  if (breeding_status !== '已配对') {
    const active = db.prepare(
      "SELECT id, male_id, female_id FROM pairings WHERE (male_id=? OR female_id=?) AND status='已配对' LIMIT 1"
    ).get(id, id);
    if (active) {
      // 结束配对记录
      db.prepare("UPDATE pairings SET status='已拆对', end_date=date('now') WHERE id=?").run(active.id);
      // 对方设为未配对
      const mateId = active.male_id === id ? active.female_id : active.male_id;
      db.prepare("UPDATE birds SET breeding_status='未配对' WHERE id=?").run(mateId);
    }
  }

  // 如果改为已配对且有配偶，创建配对记录
  if (breeding_status === '已配对' && mate_id) {
    const mid = parseInt(mate_id);
    const bird = db.prepare('SELECT id, gender FROM birds WHERE id=?').get(id);
    const mate = db.prepare('SELECT id, gender FROM birds WHERE id=?').get(mid);
    if (bird && mate) {
      const maleId = bird.gender === '公' ? bird.id : mate.id;
      const femaleId = bird.gender === '母' ? bird.id : mate.id;

      // 解除双方原有的所有活跃配对
      const toEnd = new Set();
      for (const pid of db.prepare("SELECT id FROM pairings WHERE (male_id=? OR female_id=?) AND status='已配对'").all(id, id)) { toEnd.add(pid.id); }
      for (const pid of db.prepare("SELECT id FROM pairings WHERE (male_id=? OR female_id=?) AND status='已配对'").all(mid, mid)) { toEnd.add(pid.id); }
      for (const pid of toEnd) {
        db.prepare("UPDATE pairings SET status='已拆对', end_date=date('now') WHERE id=?").run(pid);
        // 把对方的配对状态设为未配对
        const p = db.prepare('SELECT male_id, female_id FROM pairings WHERE id=?').get(pid);
        if (p) {
          const other = p.male_id === id ? p.female_id : p.male_id;
          db.prepare("UPDATE birds SET breeding_status='未配对' WHERE id=? AND breeding_status='已配对'").run(other);
        }
      }

      // 创建新配对
      db.prepare('INSERT INTO pairings (male_id, female_id, start_date, status) VALUES (?,?,date(\'now\'),\'已配对\')').run(maleId, femaleId);
      // 标记配偶也为已配对
      db.prepare("UPDATE birds SET breeding_status='已配对' WHERE id=?").run(mid);
    }
  }

  res.redirect(`/bird/${id}`);
});

// ---- 删除鸟 ----
app.post('/bird/:id/delete', (req, res) => {
  const id = parseInt(req.params.id);
  const bird = db.prepare('SELECT image_path FROM birds WHERE id=?').get(id);

  // 清理关联数据
  db.prepare('DELETE FROM weight_records WHERE bird_id=?').run(id);
  db.prepare('DELETE FROM bird_mutations WHERE bird_id=?').run(id);
  db.prepare('DELETE FROM relationship_cache WHERE bird_a_id=? OR bird_b_id=?').run(id, id);

  // 解除配对
  const activePairs = db.prepare("SELECT id FROM pairings WHERE (male_id=? OR female_id=?) AND status='已配对'").all(id, id);
  for (const p of activePairs) {
    const pp = db.prepare('SELECT male_id, female_id FROM pairings WHERE id=?').get(p.id);
    const other = pp.male_id === id ? pp.female_id : pp.male_id;
    db.prepare("UPDATE birds SET breeding_status='未配对' WHERE id=?").run(other);
    db.prepare("UPDATE pairings SET status='已拆对', end_date=date('now') WHERE id=?").run(p.id);
  }
  // 清理后代关联
  db.prepare('UPDATE birds SET father_id=NULL WHERE father_id=?').run(id);
  db.prepare('UPDATE birds SET mother_id=NULL WHERE mother_id=?').run(id);

  // 删除相关繁殖记录
  const pairIds = db.prepare('SELECT id FROM pairings WHERE male_id=? OR female_id=?').all(id, id).map(p => p.id);
  for (const pid of pairIds) {
    const evIds = db.prepare('SELECT id FROM breeding_events WHERE pair_id=?').all(pid).map(e => e.id);
    for (const eid of evIds) {
      db.prepare('DELETE FROM eggs WHERE breeding_event_id=?').run(eid);
      db.prepare('DELETE FROM offspring WHERE breeding_event_id=?').run(eid);
    }
    db.prepare('DELETE FROM breeding_events WHERE pair_id=?').run(pid);
    db.prepare('DELETE FROM pairings WHERE id=?').run(pid);
  }

  // 删除照片
  if (bird && bird.image_path) {
    const photoPath = path.join(uploadDir, path.basename(bird.image_path));
    if (fs.existsSync(photoPath)) fs.unlinkSync(photoPath);
  }

  db.prepare('DELETE FROM birds WHERE id=?').run(id);
  res.redirect('/');
});

// ---- 配对详情页 ----
app.get('/pairing/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const pairing = db.prepare(`
    SELECT p.*, 
      m.id AS male_id, m.name AS male_name, m.ring_number AS male_ring,
      f.id AS female_id, f.name AS female_name, f.ring_number AS female_ring
    FROM pairings p
    JOIN birds m ON m.id = p.male_id
    JOIN birds f ON f.id = p.female_id
    WHERE p.id = ?
  `).get(id);
  if (!pairing) return res.redirect('/');

  const events = db.prepare(`
    SELECT * FROM breeding_events WHERE pair_id = ? ORDER BY event_date DESC
  `).all(id);

  // 蛋明细
  const eggs = {};
  for (const ev of events) {
    eggs[ev.id] = db.prepare(`
      SELECT * FROM eggs WHERE breeding_event_id = ? ORDER BY egg_number
    `).all(ev.id);
  }

  // 后代的鸟信息
  const offspring = db.prepare(`
    SELECT o.*, b.name, b.ring_number, b.gender, b.color_desc
    FROM offspring o
    JOIN birds b ON b.id = o.bird_id
    WHERE o.breeding_event_id IN (SELECT id FROM breeding_events WHERE pair_id = ?)
    ORDER BY o.hatch_order
  `).all(id);

  const species = db.prepare('SELECT id, name_cn FROM species ORDER BY id').all();
  res.render('pairing', { pairing, events, offspring, species, eggs });
});

// 新增一窝
app.post('/pairing/:id/event/new', (req, res) => {
  const id = parseInt(req.params.id);
  const maxClutch = db.prepare('SELECT COALESCE(MAX(clutch_number),0) AS c FROM breeding_events WHERE pair_id=?').get(id);
  db.prepare('INSERT INTO breeding_events (pair_id, event_date, clutch_number) VALUES (?,date(\'now\'),?)').run(id, maxClutch.c + 1);
  res.redirect('/pairing/' + id);
});

// 新增蛋
app.post('/pairing/:id/event/:eid/egg', (req, res) => {
  const eid = parseInt(req.params.eid);
  const maxNum = db.prepare('SELECT COALESCE(MAX(egg_number),0) AS n FROM eggs WHERE breeding_event_id=?').get(eid);
  const now = new Date();
  const defaultDt = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + ' ' + String(now.getHours()).padStart(2,'0') + ':00';
  const { lay_date, status } = req.body;
  db.prepare('INSERT INTO eggs (breeding_event_id, egg_number, lay_date, status, status_date) VALUES (?,?,?,?,?)').run(
    eid, maxNum.n + 1, lay_date || defaultDt, status || '待检查', defaultDt
  );
  res.redirect('/pairing/' + req.params.id);
});

// 更新蛋（含编辑弹窗提交）
app.post('/pairing/:id/egg/:eggid', (req, res) => {
  const eggid = parseInt(req.params.eggid);
  const { egg_number, lay_date, status, status_date, notes } = req.body;
  const now = new Date();
  const defaultDt = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + ' ' + String(now.getHours()).padStart(2,'0') + ':00';
  db.prepare('UPDATE eggs SET egg_number=?, lay_date=?, status=?, status_date=?, notes=? WHERE id=?').run(
    parseInt(egg_number) || 0, lay_date || defaultDt, status || '待检查', status_date || defaultDt, notes || null, eggid
  );
  res.redirect('/pairing/' + req.params.id);
});

// 删除蛋
app.post('/pairing/:id/egg/:eggid/delete', (req, res) => {
  const eggid = parseInt(req.params.eggid);
  const egg = db.prepare('SELECT breeding_event_id FROM eggs WHERE id=?').get(eggid);
  if (egg) {
    db.prepare('DELETE FROM eggs WHERE id=?').run(eggid);
    // 重新排序蛋序号
    const remaining = db.prepare('SELECT id FROM eggs WHERE breeding_event_id=? ORDER BY egg_number, id').all(egg.breeding_event_id);
    remaining.forEach(function(r, idx) {
      db.prepare('UPDATE eggs SET egg_number=? WHERE id=?').run(idx + 1, r.id);
    });
  }
  res.redirect('/pairing/' + req.params.id);
});

// 自动更新配对状态（根据年龄）
function autoUpdateBreedingStatus() {
  const birds = db.prepare('SELECT id, hatch_date, breeding_status FROM birds WHERE hatch_date IS NOT NULL').all();
  let updates = 0;
  const now = new Date();

  for (const b of birds) {
    const hatch = new Date(b.hatch_date);
    const months = (now.getFullYear() - hatch.getFullYear()) * 12 + (now.getMonth() - hatch.getMonth());
    let newStatus = null;

    if (months < 8 && b.breeding_status !== '不可配对') {
      newStatus = '不可配对';
    } else if (months >= 48 && b.breeding_status !== '不可配对') {
      newStatus = '不可配对';
    } else if (months >= 8 && months < 48 && b.breeding_status === '不可配对') {
      newStatus = '未配对';
    }

    if (newStatus) {
      db.prepare('UPDATE birds SET breeding_status=? WHERE id=?').run(newStatus, b.id);
      console.log('  ' + b.id + ': ' + b.breeding_status + ' → ' + newStatus + ' (' + months + '个月)');
      updates++;
    }
  }
  if (updates > 0) console.log('✅ 自动更新了 ' + updates + ' 只鸟的配对状态');
  return updates;
}

// 启动
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🦜 鸟舍管理系统已启动`);
  console.log(`📎 http://127.0.0.1:${PORT}`);
  autoUpdateBreedingStatus();
  // 每6小时自动检查一次
  setInterval(autoUpdateBreedingStatus, 6 * 60 * 60 * 1000);
});
